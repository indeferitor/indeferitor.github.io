document.addEventListener("DOMContentLoaded", () => {
  const checkboxes = document.querySelectorAll('input[type="checkbox"]:not(.parent)');
  const parentCheckboxes = document.querySelectorAll('.parent');
  const output = document.getElementById('output');
  const copiedMsg = document.getElementById('copiedMsg');
  const btnCalcular = document.getElementById("btnCalcularMaioridade");
  const btnLimpar = document.getElementById("btnLimparTudo");
  const btnVerificar = document.getElementById("verificar");
  const inputNascimento = document.getElementById("dataNascimento");
  const inputDataProtocolo = document.getElementById("data");

  function updateOutput() {
    const selectedValues = Array.from(checkboxes)
      .filter(cb => cb.checked)
      .map(cb => cb.value);

    const letters = 'abcdefghijklmnopqrstuvwxyz';
    const formattedText = selectedValues.map((item, index) => `${letters[index]}) ${item}`).join('\n');

    output.value = formattedText;
    copyToClipboard(formattedText);
  }

  function copyToClipboard(text) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        showCopiedMessage();
      }).catch(err => {
        console.error('Erro ao copiar:', err);
      });
    }
  }

  function showCopiedMessage() {
    copiedMsg.style.display = "inline";
    setTimeout(() => copiedMsg.style.display = "none", 2000);
  }

  function clearAll() {
    document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
    document.querySelectorAll('.sub-options').forEach(div => div.style.display = 'none');
    if (output) output.value = '';
    if (copiedMsg) copiedMsg.style.display = "none";

    const dataNascimento = document.getElementById('dataNascimento');
    if (dataNascimento) dataNascimento.value = '';

    const dataProtocolo = document.getElementById('data');
    if (dataProtocolo) dataProtocolo.value = '';

    const resultadoMaioridade = document.getElementById('resultadoMaioridade');
    if (resultadoMaioridade) {
      resultadoMaioridade.textContent = '';
      resultadoMaioridade.style.color = '';
    }

    const resultadoProtocolo = document.getElementById('resultado');
    if (resultadoProtocolo) {
      resultadoProtocolo.textContent = '';
      resultadoProtocolo.className = 'category resultado';
    }
  }

  function toggleSubOptions(parent) {
    const target = document.getElementById(parent.dataset.target);
    const isChecked = parent.checked;

    if (target) {
      target.style.display = isChecked ? 'block' : 'none';

      if (!isChecked) {
        target.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
      }
      updateOutput();
    }
  }

  function calcularMaioridade() {
    const input = document.getElementById("dataNascimento").value;
    const resultado = document.getElementById("resultadoMaioridade");

    if (!input) {
      resultado.textContent = "Por favor, insira a data de nascimento.";
      resultado.style.color = "#b30000";
      return;
    }

    const [ano, mes, dia] = input.split("-").map(Number);
    const dataNascimento = new Date(ano, mes - 1, dia);
    const dataMaioridade = new Date(ano + 18, mes - 1, dia);
    const hoje = new Date();

    const textoData = `${String(dataMaioridade.getDate()).padStart(2, '0')}/${String(dataMaioridade.getMonth() + 1).padStart(2, '0')}/${dataMaioridade.getFullYear()}`;

    if (hoje >= dataMaioridade) {
      resultado.textContent = `Maior de idade em ${textoData} ✅`;
      resultado.style.color = "green";
    } else {
      resultado.textContent = `Maior de idade em ${textoData} ❌`;
      resultado.style.color = "#b30000";
    }
  }

  function verificarDataProtocolo() {
    const input = document.getElementById("data").value;
    const resultado = document.getElementById("resultado");

    if (!input) {
      resultado.innerHTML = "Por favor, insira uma data de protocolo.";
      resultado.className = "category resultado vermelho";
      return;
    }

    const dataInformada = new Date(input + "T00:00:00");
    const diaSemana = dataInformada.getDay();
    const nomesDias = [
      "Domingo", "Segunda-feira", "Terça-feira",
      "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"
    ];

    const inicio = new Date("2010-01-01");
    const fim = new Date("2021-10-01");

    let textoResultado = "";
    let classe = "";

    if (dataInformada < inicio || dataInformada > fim) {
      textoResultado = `Fora do Período de Protocolos Aceitos\n${nomesDias[diaSemana]}`;
      classe = "vermelho";
    } else if (diaSemana === 0 || diaSemana === 6) {
      textoResultado = `Dia da Semana Inválido\nFim de Semana: ${nomesDias[diaSemana]}`;
      classe = "vermelho";
    } else {
      textoResultado = `Dia da Semana Válido: ${nomesDias[diaSemana]}\nDentro do Período de Protocolos Aceitos`;
      classe = "verde";
    }

    resultado.innerHTML = textoResultado.replace(/\n/g, "<br>");
    resultado.className = `category resultado ${classe}`;
  }

  // ➔ Função para animar botão ao "clicar" (piscar)
  function animateButton(button) {
    if (!button) return;
    button.classList.add('clicked');
    setTimeout(() => button.classList.remove('clicked'), 200); // 200 ms
  }

  // Eventos principais
  checkboxes.forEach(cb => cb.addEventListener('change', updateOutput));
  parentCheckboxes.forEach(parent => parent.addEventListener('change', () => toggleSubOptions(parent)));

  if (btnCalcular) btnCalcular.addEventListener("click", calcularMaioridade);
  if (btnLimpar) btnLimpar.addEventListener("click", clearAll);
  if (btnVerificar) btnVerificar.addEventListener("click", verificarDataProtocolo);

  // ➔ Permitir ENTER nos inputs
  if (inputNascimento) {
    inputNascimento.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        calcularMaioridade();
        animateButton(btnCalcular);
      }
    });
  }

  if (inputDataProtocolo) {
    inputDataProtocolo.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        verificarDataProtocolo();
        animateButton(btnVerificar);
      }
    });
  }
  if (btnCalcular) {
  btnCalcular.addEventListener("click", () => {
    calcularMaioridade();
    animateButton(btnCalcular); // adiciona animação no clique também
  });
}

if (btnLimpar) {
  btnLimpar.addEventListener("click", () => {
    clearAll();
    animateButton(btnLimpar); // opcional, se quiser animar também o botão limpar
  });
}

if (btnVerificar) {
  btnVerificar.addEventListener("click", () => {
    verificarDataProtocolo();
    animateButton(btnVerificar); // adiciona animação no clique também
  });
}

});
