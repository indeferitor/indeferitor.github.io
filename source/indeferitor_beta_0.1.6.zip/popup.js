document.addEventListener('DOMContentLoaded', () => {
  const toggleButton = document.getElementById('toggleSidebar');
  toggleButton.textContent = 'Ativar';

  toggleButton.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    await chrome.sidePanel.open({ tabId: tab.id });

    // Se quiser, ainda pode salvar que foi ativada
    chrome.storage.local.set({ 'sidebarAtiva': true });
  });
});
