document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggleSidebar');
  
    chrome.storage.local.get('sidebarAtiva', (data) => {
      toggleButton.textContent = data.sidebarAtiva ? 'Desligar Barra Lateral' : 'Ligar Barra Lateral';
    });
  
    toggleButton.addEventListener('click', async () => {
      chrome.storage.local.get('sidebarAtiva', async (data) => {
        const ativa = !data.sidebarAtiva;
        chrome.storage.local.set({ 'sidebarAtiva': ativa });
        toggleButton.textContent = ativa ? 'Desligar Barra Lateral' : 'Ligar Barra Lateral';
  
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
        if (ativa) {
          await chrome.sidePanel.open({ tabId: tab.id });
        } else {
          // Não há uma API direta para fechar a side panel programaticamente.
          // A melhor abordagem é talvez mudar o conteúdo para algo vazio ou
          // instruir o usuário a fechar manualmente.
          // Para simplificar, vamos focar em abrir. O usuário pode fechar manualmente.
          // Uma alternativa mais complexa seria injetar um script na página para
          // adicionar um botão de fechar na própria barra lateral.
        }
      });
    });
  });