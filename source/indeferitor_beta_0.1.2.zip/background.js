chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ sidebarAtiva: false }); // Inicializa o estado da barra lateral como desligada
    console.log('Extensão instalada com a barra lateral desligada.');
  });
  
  chrome.action.onClicked.addListener(async (tab) => {
    // Ao clicar no ícone, o popup será aberto (definido no manifest)
  });
  
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "updatePopup") {
      // Solicitação do sidebar.html para atualizar o texto do botão no popup
      chrome.action.setPopup({ popup: "popup.html" }); // Força uma atualização do popup
    }
  });
  
  chrome.sidePanel.onOpen.addListener(async () => {
    chrome.storage.local.set({ 'sidebarAtiva': true });
    // Opcional: Enviar uma mensagem para a barra lateral quando ela é aberta
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      chrome.runtime.sendMessage({ action: "updateSidebarContent" }, { tabId: tab.id });
    }
  });