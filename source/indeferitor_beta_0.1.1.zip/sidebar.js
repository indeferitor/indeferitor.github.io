    const checkboxes = document.querySelectorAll('input[type="checkbox"]:not(.parent)');
    const parentCheckboxes = document.querySelectorAll('.parent');
    const output = document.getElementById('output');
    const copiedMsg = document.getElementById('copiedMsg');

    function updateText() {
      const selected = Array.from(checkboxes)
        .filter(cb => cb.checked)
        .map(cb => cb.value);

      const letters = 'abcdefghijklmnopqrstuvwxyz';
      let result = "Infelizmente o seu pedido de registro inicial foi indeferido, segue(m) o(s) motivo(s):\n\n";
      result += "I - Quanto à documentação e às informações inseridas pelo interessado:\n\n";

      selected.forEach((item, index) => {
        result += `${letters[index]}) ${item}\n`;
      });

      output.value = result;

      // Copiar para área de transferência
      navigator.clipboard.writeText(result).then(() => {
        copiedMsg.style.display = "inline";
        setTimeout(() => copiedMsg.style.display = "none", 2000);
      });
    }

    checkboxes.forEach(cb => cb.addEventListener('change', updateText));

    parentCheckboxes.forEach(parent => {
      parent.addEventListener('change', () => {
        const target = document.getElementById(parent.dataset.target);
        target.style.display = parent.checked ? 'block' : 'none';

        // Desmarca as subopções ao esconder
        if (!parent.checked) {
          target.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.checked = false;
          });
          updateText();
        }
      });
    });

    function clearAll() {
      document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
      document.querySelectorAll('.sub-options').forEach(div => div.style.display = 'none');
      output.value = '';
      copiedMsg.style.display = "none";
    }
    
    function calcularMaioridade() {
      const input = document.getElementById("dataNascimento").value;
      const resultado = document.getElementById("resultadoMaioridade");
  
      if (!input) {
        resultado.textContent = "Por favor, insira a data de nascimento.";
        resultado.style.color = "#b30000";
        return;
      }
  
      const [ano, mes, dia] = input.split("-").map(Number);
      const dataNascimento = new Date(ano, mes - 1, dia);
      const dataMaioridade = new Date(ano + 18, mes - 1, dia);
  
      const hoje = new Date();
      const diaFormatado = String(dataMaioridade.getDate()).padStart(2, '0');
      const mesFormatado = String(dataMaioridade.getMonth() + 1).padStart(2, '0');
      const anoFormatado = dataMaioridade.getFullYear();
  
      const textoData = `${diaFormatado}/${mesFormatado}/${anoFormatado}`;
  
      if (hoje >= dataMaioridade) {
        resultado.textContent = `Maior de idade em ${textoData} ✅`;
        resultado.style.color = "green";
      } else {
        resultado.textContent = `Maior de idade em ${textoData} ❌`;
        resultado.style.color = "#b30000";
      }
    }
  
document.addEventListener("DOMContentLoaded", () => {
  const btnCalcular = document.getElementById("btnCalcularMaioridade");
  if (btnCalcular) {
    btnCalcular.addEventListener("click", calcularMaioridade);
  }

  const btnLimpar = document.getElementById("btnLimparTudo");
  if (btnLimpar) {
    btnLimpar.addEventListener("click", clearAll);
  }
});
